A Pen created at CodePen.io. You can find this one at https://codepen.io/rafaelcastrocouto/pen/LFAes.

 basic CSS template for A4 print

BONUS: includes style for A2 and A5!